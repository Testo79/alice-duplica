const form = document.getElementById("login-form");
const msg = document.getElementById("form-message");
const submitBtn = document.getElementById("submit-btn");
const btnLabel = submitBtn.querySelector(".btn-label");
const btnSpinner = submitBtn.querySelector(".btn-spinner");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "";
  msg.className = "form-message";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    msg.textContent = "Fyll i e-post och lösenord.";
    msg.classList.add("err");
    return;
  }

  submitBtn.disabled = true;
  btnLabel.hidden = true;
  btnSpinner.hidden = false;

  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));

    if (!res.ok || !data.ok) {
      msg.textContent = data.message || "Något gick fel. Försök igen.";
      msg.classList.add("err");
      return;
    }

    window.location.assign("/tack.html");
    return;
  } catch {
    msg.textContent = "Anslutningen misslyckades. Kontrollera nätverket.";
    msg.classList.add("err");
  } finally {
    submitBtn.disabled = false;
    btnLabel.hidden = false;
    btnSpinner.hidden = true;
  }
});
